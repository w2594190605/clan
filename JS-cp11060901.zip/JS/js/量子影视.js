var rule= {
模板:'mxone5',
title:'量子影视',
host:'http://www.lzizy9.com',
url:'/index.php/vod/show/id/fyclass/page/fypage.html',
searchUrl:'/index.php/vod/search.html?wd=**',
cate_exclude:'网址'
}
