var rule = Object.assign(muban.vfed,{
title:'VIP影院',
host:'http://360yy.cn',
url:'/index.php/vod/show/id/fyclass/page/fypage.html',
searchUrl:'/index.php/vod/search/page/fypage/wd/**.html',
});